import './App.css';
import EnrollmentForm from './Components/EnrollmentForm';

function App() {
  return (
    <div id="system">
      <EnrollmentForm/>
    </div>
  );
}

export default App;
